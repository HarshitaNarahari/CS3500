import org.junit.Test;

import java.util.Iterator;

import ledger.BudgetStatus;
import ledger.ItemType;
import ledger.Ledger;
import ledger.LedgerItem;
import ledger.BudgetLedger;
import ledger.SimpleLedger;

import static org.junit.Assert.*;

public class LedgerTests {

  @Test
  public void testUsage() {
    //create an empty ledger
    Ledger accountBook = new SimpleLedger();

    //add monthly salary
    accountBook.addIncome("Salary",1000,00,1,1,2021);

    //rent
    accountBook.addExpense("Rent",500,0,5,1,2021);
    //cell phone bill
    accountBook.addExpense("Cell Phone",50,10,10,1,2021);
    //groceries
    accountBook.addExpense("Groceries",100,52,30,1,2021);

    //get all the incomes
    //the order in which the expected items are
    String []itemNames = {"Salary"};
    double []amounts = {1000.00};
    testItems(accountBook.allIncomes(),itemNames,amounts);

    //get all the expenses
    //the order in which the expected items are
    itemNames = new String[]{"Rent","Cell Phone","Groceries"};
    amounts = new double[]{500.00,50.10,100.52};
    testItems(accountBook.allExpenses(),itemNames,amounts);

    //verify total income
    assertEquals(1000,accountBook.getTotalIncome(),0.01);
    //verify total expenses
    assertEquals(650.62,accountBook.getTotalExpenses(),0.01);

    //help from parents! (Will pay back later)
    accountBook.addIncome("Advance from parents",400,0,15,1,2021);

    //get all the incomes again
    //the order in which the expected items are
    itemNames = new String[]{"Salary","Advance from parents"};
    amounts = new double[]{1000.00,400};
    testItems(accountBook.allIncomes(),itemNames,amounts);

    //get all the expenses again
    //the order in which the expected items are
    itemNames = new String[]{"Rent","Cell Phone","Groceries"};
    amounts = new double[]{500.00,50.10,100.52};
    testItems(accountBook.allExpenses(),itemNames,amounts);

    //verify total income
    assertEquals(1400,accountBook.getTotalIncome(),0.01);
    //verify total expenses
    assertEquals(650.62,accountBook.getTotalExpenses(),0.01);
  }

  private void testItems(Iterator<LedgerItem> items,String[] itemNames,double[] amounts) {
    int count = 0;
    while (items.hasNext()) {
      LedgerItem item = items.next();
      assertEquals(itemNames[count],item.getDescription());
      assertEquals(amounts[count],item.getAmount(),0.01);
      count = count + 1;
    }
    assertEquals(count, itemNames.length);
    assertEquals(count,amounts.length);
  }

  @Test
  public void testBudgeter() {
    //create a budgeter with a fixed budget
    BudgetLedger fixedBudgeter = new BudgetLedger(100);

    //verify that we are under budget and find out how much we can spend
    assertEquals(BudgetStatus.UnderBudget, fixedBudgeter.budgetStatus());

    //add some expenses, still within budget
    fixedBudgeter.addExpense("Shrug", 20.0);
    fixedBudgeter.addExpense("Gloves", 10.0);
    fixedBudgeter.addExpense("Boots", 30.0);
    fixedBudgeter.addExpense("Scarf", 10.0);

    //verify that we are still under budget and find out how much we can spend
    assertEquals(BudgetStatus.UnderBudget, fixedBudgeter.budgetStatus());

    //spend the remaining money
    fixedBudgeter.addExpense("Jacket", 30.0);

    //verify that we are now at budget
    assertEquals(BudgetStatus.ReachedBudget, fixedBudgeter.budgetStatus());

    //spend some more...'coz we just can't help it!
    fixedBudgeter.addExpense("Jeans", 25.0);
    fixedBudgeter.addExpense("Watch", 100.0);

    //verify that we went over budget and that we don't have any more to spend
    assertEquals(BudgetStatus.OverBudget, fixedBudgeter.budgetStatus());
  }



  @Test
  public void testLedgerConditions() {
    Ledger ledgerA = new SimpleLedger();
    Ledger ledgerB = new SimpleLedger();

// added incomes and expenses > ledger A
    ledgerA.addIncome("Phone", 600, 50, 15, 7, 2023);
    ledgerA.addIncome("Rent", 5500, 50, 20, 7, 2023);


    ledgerA.addExpense("Electricity bill", 500, 0, 29, 7, 2023);
    ledgerA.addExpense("Travel to boston", 1000, 0, 29, 7, 2023);
    ledgerA.addExpense("Travel to india", 2000, 0, 29, 7, 2023);

// verified that A > report all expenses, all incomes and their correct totals
    assertEquals(3500, ledgerA.getTotalExpenses(), 0.01);
    assertEquals(6101, ledgerA.getTotalIncome(), 0.01);


// adding identical items to B from A above
    ledgerB.addIncome("Phone", 600, 50, 15, 7, 2023);
    ledgerB.addIncome("Rent", 5500, 50, 20, 7, 2023);

    ledgerB.addExpense("Electricity bill", 500, 0, 29, 7, 2023);
    ledgerB.addExpense("travel to boston", 1000, 0, 29, 7, 2023);
    ledgerB.addExpense("travel to india", 2000, 0, 29, 7, 2023);

// verified that B > correctly find expenses that have the word "travel" in their description
    assertEquals(3000, ledgerB.calculateTotalIncomeDescription("travel"), 0.01);

// verified that B > correctly find the total of all incomes that are above $5000
    assertEquals(5500, ledgerB.calculateTotalExpensesAboveAmount(5500), 0.01);

// verified that B can correctly find the total of all expenses
    assertEquals(3500, ledgerB.getTotalExpenses(), 0.01);


// verified > B matches what A returned for the same query
    assertEquals(3500, ledgerA.getTotalExpenses(), 0.01);
    assertEquals(ledgerA.getTotalExpenses(), ledgerB.getTotalExpenses(), 0.01);


// added income worth $10000 to B
    ledgerB.addIncome("Louis Vuitton Bag",10000, 0, 06, 20, 2023);


// verified that B > correctly find the total of all incomes that are above $5000
    assertEquals(15500, ledgerB.calculateTotalExpensesAboveAmount(5000), 0.01);

  }


}