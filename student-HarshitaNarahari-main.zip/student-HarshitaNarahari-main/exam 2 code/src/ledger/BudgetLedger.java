package ledger;

/**
 * This class represents a simple ledger. It records expenses and income
 * in the order in which they were entered.
 */

// class represents my ledger implementation with the constraints listed above

public class BudgetLedger {
  private final double budget;
  private final Ledger ledger;

// constructor
  public BudgetLedger(double budget) {
    this.budget = budget;
    this.ledger = new SimpleLedger();
  }

  @Override
  public void addExpense(String description, double amount) throws IllegalArgumentException {
// ensures that expenses can be added irrespective of whether he is over budget or not
    if (amount < 0) {
      throw new IllegalArgumentException("Amount can't be negative");
    }
    ledger.addExpense(description, (int) amount, (int) amount * 100, 0, 0, 0);
  }

  // calculates the budget left, returns 0 if Paul has gone over budget
  double currentBudget() {
    double budgetLeft = budget - ledger.getTotalExpenses();

    if (budgetLeft < 0){
      budgetLeft = 0;
    }
    return budgetLeft;
  }

  // states paul's budget status
  // Paul should be able to query how much money he has left to spend in his budget.
  public BudgetStatus budgetStatus() {
    if (budget < ledger.getTotalExpenses()){
      return BudgetStatus.OverBudget;
    }
    if (budget > ledger.getTotalExpenses()){
      return BudgetStatus.UnderBudget;
    }
    return BudgetStatus.ReachedBudget;
  }
}