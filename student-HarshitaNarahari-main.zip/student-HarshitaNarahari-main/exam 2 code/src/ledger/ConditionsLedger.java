package ledger;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class ConditionsLedger implements LedgerConditions {
  private List<LedgerItem> items;
  private final Ledger ledger;

  ConditionsLedger() {
    ledger = new SimpleLedger();
    items = new LinkedList<LedgerItem>();
  }

  // Find all expenses (or their sum) above a certain amount.
  @Override
  public double calculateTotalExpensesAboveAmount(double amount) {
    amount = 0.0;

    for (LedgerItem item : items) {
      if (item.getAmount() > amount) {
        amount += item.getAmount();
      }
    }
    return amount;
  }

  // Find all expenses (or their sum) in a range.
  @Override
  public double calculateTotalExpensesInRange(double minAmount, double maxAmount) {
    double amount = 0.0;

    for (LedgerItem item : items) {
      if (item.getAmount() >= minAmount && item.getAmount() <= maxAmount) {
        amount += item.getAmount();
      }
    }
    return amount;
  }

  public double calculateTotalIncomeDescription(String description) {
    double amount = 0.0;

    for (LedgerItem item : items) {
      if (item.getDescription() == description) {
        amount += item.getAmount();
      }
    }
    return amount;
  }

  public double findIncomesAndExpensesInPeriod(SimpleDate startDate, SimpleDate endDate) {
    double amount = 0.0;
    for (LedgerItem item : this.items) {
      if (item.getDateOccurred().getDate() >= startDate.getDate() &&
              item.getDateOccurred().getMonth() >= startDate.getMonth() &&
              item.getDateOccurred().getYear() >= startDate.getYear() &&
              item.getDateOccurred().getDate() <= endDate.getDate() &&
              item.getDateOccurred().getMonth() <= endDate.getMonth() &&
              item.getDateOccurred().getYear() <= endDate.getYear()) {
        amount += item.getAmount();
      }
    }
    return amount;
  }
}
