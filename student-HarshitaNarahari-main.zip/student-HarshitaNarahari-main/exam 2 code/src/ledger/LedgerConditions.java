package ledger;

import java.util.Iterator;

public interface LedgerConditions {
  // Find all expenses (or their sum) above a certain amount.
  double calculateTotalExpensesAboveAmount(double amount);
  //Find all expenses (or their sum) within a certain range of amounts.
  double calculateTotalExpensesInRange(double minAmount, double maxAmount);
  // Find all incomes (or their sum) with a description that includes "food".
  double calculateTotalIncomeDescription(String description);
  // Find all incomes and expenses occurring in a given period (e.g. 1 January 2022 to 12 February 2022).
  double findIncomesAndExpensesInPeriod(SimpleDate startDate, SimpleDate endDate);

}
