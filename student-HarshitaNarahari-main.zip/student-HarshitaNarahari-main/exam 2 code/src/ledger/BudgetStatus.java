package ledger;

public enum BudgetStatus {
  OverBudget, UnderBudget, ReachedBudget
}
