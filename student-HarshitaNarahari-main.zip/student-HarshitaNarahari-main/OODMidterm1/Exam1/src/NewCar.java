/**
 * To represent a class for New Cars
 */
public class NewCar extends ACar {
  private Integer availableVehiclesIn50miles;

  /**
   * Constructs a NewCar
   *
   * @throws IllegalArgumentException if there's a negative number of available vehicles within 50 miles.
   */
  NewCar(String id, int manufacturingYear, float msrp, MakeModel makeModel, BodyType bodyType,
         int availableVehiclesIn50miles) throws IllegalArgumentException{
    super(id, manufacturingYear, msrp, makeModel, bodyType);
    if (availableVehiclesIn50miles < 0){
      throw new IllegalArgumentException("There cannot be a negative number of available vehicles within 50 miles.");
    }
    this.availableVehiclesIn50miles = availableVehiclesIn50miles;
  }

  /**
   * Estimates the price if there are less than 15 available vehicle within 50 miles
   *
   * @return Float representing the updated base price (price)
   */
  public Float estimatePrice(){
    Float basePrice = super.estimatePrice();
    if (availableVehiclesIn50miles < 15){
      basePrice *= (float) 1.2;
    }
    return basePrice;
  }
}
