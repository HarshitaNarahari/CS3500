/**
 * Represents an interface for IVehicle
 */

public interface IVehicle {

  /**
   * Estimates and updates the price based on the conditions in each class
   *
   * @return Float representing the updated base price (price)
   */
  Float estimatePrice();

}
