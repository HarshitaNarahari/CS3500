/**
 * To represent an abstract class for Vessels
 */
public abstract class AVessel extends AVehicle{

  /**
   * Constructs a Vessel
   */
  AVessel(String id, int manufacturingYear, float msrp, MakeModel makeModel){
    super(id, manufacturingYear, msrp, makeModel);
  }


}
