/**
 * To represent a class for Used Cars
 */
public class UsedCar extends ACar {

  private Integer mileage;
  private Integer numPreviousOwners;
  private Integer numMinorTrafficAccidents;
  private Boolean certifiedPreOwnedStatus;

  /**
   * Constructs a UsedCar
   *
   * @throws IllegalArgumentException if mileage is negative.
   * @throws IllegalArgumentException if number of previous owners is negative.
   * @throws IllegalArgumentException if number of minor traffic accidents is negative.
   */
  UsedCar(String id, int manufacturingYear, float msrp, MakeModel makeModel, BodyType bodyType,
          int availableVehiclesIn50miles, int mileage, int numPreviousOwners,
          int numMinorTrafficAccidents, boolean certifiedPreOwnedStatus) throws IllegalArgumentException{

    super(id, manufacturingYear, msrp, makeModel, bodyType);
    if (mileage < 0){
      throw new IllegalArgumentException("Mileage cannot be negative.");
    }
    this.mileage = mileage;
    if (numPreviousOwners < 0){
      throw new IllegalArgumentException("Number of previous owners cannot be negative.");
    }
    this.numPreviousOwners = numPreviousOwners;
    if (numMinorTrafficAccidents < 0){
      throw new IllegalArgumentException("Number of minor traffic accidents cannot be negative.");
    }
    this.numMinorTrafficAccidents = numMinorTrafficAccidents;
    this.certifiedPreOwnedStatus = certifiedPreOwnedStatus;
  }

  /**
   * Estimates the price if the mileage is greater than 300000,
   * if the number of previous owners is greater than 5 and is not certified pre-owned,
   * if the number of minor traffic accidents is greater than 2
   *
   * @return Float representing the updated base price (price)
   */
  public Float estimatePrice(){
    Float basePrice = super.estimatePrice();
    if (mileage > 300000){
      basePrice *= (float) 0.75;
    }
    if (numPreviousOwners > 5 && certifiedPreOwnedStatus == false){
      basePrice *= (float) 0.8;
    }
    if (numMinorTrafficAccidents > 2){
      basePrice *= (float) 0.65;
    }
    return basePrice;
  }

}
