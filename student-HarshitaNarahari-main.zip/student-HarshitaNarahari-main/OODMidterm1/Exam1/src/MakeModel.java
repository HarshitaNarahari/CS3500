/**
 * To represent a class for MakeModels
 */
public class MakeModel{

  private String make;
  private String model;

  /**
   * Default Constructor
   */
  MakeModel(){
    this.make = "Honda";
    this.model = "Civic";
  }

  /**
   * Constructs a MakeModel
   *
   * @throws IllegalArgumentException if the make or model is null.
   */
  public MakeModel(String make, String model) throws IllegalArgumentException{
    if (make == null || model == null){
      throw new IllegalArgumentException("Make or model cannot be null.");
    }
    this.make = make;
    this.model = model;
  }
}
