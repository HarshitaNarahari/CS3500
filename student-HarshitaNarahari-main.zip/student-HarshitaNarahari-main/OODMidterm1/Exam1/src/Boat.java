/**
 * To represent a class for Boats
 */
public class Boat extends AVessel{
  private final Float boatLength;
  private final Integer numPassengers;
  private final Boolean trailable;
  private PropulsionType propulsionType;
  private BoatType boatType;

  /**
   * This enum represents the propulsion type of the boat. A boat
   * can either have a PropulsionType of SailPower, InboardEngine,
   * OutboardEngine, or JetPropulsion
   */
  enum PropulsionType {SailPower, InboardEngine, OutboardEngine, JetPropulsion}

  /**
   * This enum represents the boat type of the boat. A boat
   * can either have a BoatType of FishingBoats, Bowriders,
   * cabinCruisers, jetBoats
   */
  enum BoatType {FishingBoats, Bowriders, cabinCruisers, jetBoats}

  /**
   * Constructs a Boat
   *
   * @throws IllegalArgumentException if boat's length is negative.
   * @throws IllegalArgumentException if boat has less than one passenger.
   * @throws IllegalArgumentException boat type is null.
   * @throws IllegalArgumentException propulsion type is null.
   */
  Boat(String id, int manufacturingYear, float msrp, MakeModel makeModel,
       float boatLength, int numPassengers, boolean trailable, PropulsionType propulsionType,
       BoatType boatType) throws IllegalArgumentException{
    super(id, manufacturingYear, msrp, makeModel);
    if (boatLength < 0){
      throw new IllegalArgumentException("The boat's length cannot be negative.");
    }
    this.boatLength = boatLength;
    if (numPassengers < 1){
      throw new IllegalArgumentException("The boat must have at least one passenger.");
    }
    this.numPassengers = numPassengers;

    if (boatType == null){
      throw new IllegalArgumentException("The boat type cannot be null.");
    }
    this.boatType = boatType;
    if (propulsionType == null){
      throw new IllegalArgumentException("The propulsion type cannot be null.");
    }
    this.propulsionType = propulsionType;
    this.trailable = trailable;
  }

  /**
   * Estimates the price if there are more than 7 passengers,
   * if the propulsion type is sail power,
   * if the boat is not trailable,
   * if the boat length is less than 18 and there are less than 5 passengers
   *
   * @return Float representing the updated base price (price)
   */
  public Float estimatePrice(){
    Float basePrice = super.estimatePrice();
    if (numPassengers >= 7){
      basePrice *= (float) 1.3;
    }
    if (this.propulsionType == PropulsionType.SailPower){
      basePrice *= (float) 1.25;
    }
    if (this.trailable == false && this.boatType == BoatType.FishingBoats){
      basePrice *= (float) 0.9;
    }
    if (this.boatLength > 18 && numPassengers < 5){
      basePrice *= (float) 0.75;
    }
    return basePrice;
  }
}
