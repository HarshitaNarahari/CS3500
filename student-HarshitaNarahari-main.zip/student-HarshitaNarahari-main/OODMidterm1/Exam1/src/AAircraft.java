/**
 * To represent an abstract class for Aircrafts
 */
public abstract class AAircraft extends AVehicle{

  private Integer numQualifiedFlights;

  /**
   * Constructs an Aircraft
   *
   * @throws IllegalArgumentException if number of qualified flights is negative
   */
  AAircraft(String id, int manufacturingYear, float msrp,
            MakeModel makeModel, int numQualifiedFlights) throws IllegalArgumentException{
    super(id, manufacturingYear, msrp, makeModel);
    if(numQualifiedFlights < 0){
      throw new IllegalArgumentException("Number of qualified flights cannot be negative.");
    }
    this.numQualifiedFlights = numQualifiedFlights;
  }

  /**
   * Getter for number of qualified flights
   *
   * @return Integer representing the number of qualified flights
   */
  public Integer getnumQualifiedFlights(){
    return this.numQualifiedFlights;
  }


  /**
   * Estimates the price if there are less than 100 qualified flights
   *
   * @return Float representing the updated base price (price)
   */
  public Float estimatePrice() {
    Float basePrice = (float)(getMSRP() * 1.1);
    if(this.numQualifiedFlights < 100){
      basePrice *= (float) 1.3;
    }
    return basePrice;
  }

}
