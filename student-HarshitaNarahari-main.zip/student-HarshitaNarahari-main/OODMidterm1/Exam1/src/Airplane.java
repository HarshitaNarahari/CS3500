/**
 * To represent a class for Airplanes
 */
public class Airplane extends AAircraft{

  /**
   * Constructs an Airplane
   */
  Airplane(String id, int manufacturingYear, float msrp,
            MakeModel makeModel, int numQualifiedFlights){
    super(id, manufacturingYear, msrp, makeModel, numQualifiedFlights);
  }

  /**
   * Estimates the price if the Aircraft is an airplane
   *
   * @return Float representing the updated base price (price)
   */
  public Float estimatePrice(){
    Float basePrice = super.estimatePrice();
    return basePrice * (float) 1.4;
  }
}
