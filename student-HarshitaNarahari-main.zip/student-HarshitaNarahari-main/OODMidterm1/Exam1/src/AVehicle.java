/**
 * To represent an abstract class for Vehicles
 */
public abstract class AVehicle implements IVehicle{

  private String id;
  private Integer manufacturingYear;
  private final MakeModel makeModel;
  private Float msrp;

  /**
   * Default Constructor
   */
  AVehicle(){
    this.id = "0000";
    this.manufacturingYear = 2015;
    this.makeModel = new MakeModel();
    this.msrp = (float) 0.01;
  }

  /**
   * Constructs a Vehicle
   *
   * @throws IllegalArgumentException if id is null
   * @throws IllegalArgumentException if manufacturing year is negative.
   * @throws IllegalArgumentException if the Manufacturer Suggested Retail Price is negative.
   */
  AVehicle(String id, int manufacturingYear, float msrp, MakeModel makeModel) throws IllegalArgumentException{
    if (id == null){
      throw new IllegalArgumentException("ID cannot be null.");
    }
    this.id = id;
    if (manufacturingYear <= 0 || manufacturingYear >= 2023){
      throw new IllegalArgumentException("Manufacturing year is negative.");
    }
    this.manufacturingYear = manufacturingYear;
    this.makeModel = makeModel;
    if (msrp < 0){
      throw new IllegalArgumentException("The Manufacturer Suggested Retail Price is negative.");
    }
    this.msrp = msrp;
  }

  /**
   * Getter for Manufacturer Suggested Retail Price
   *
   * @return Float representing the Manufacturer Suggested Retail Price
   */
  public Float getMSRP(){
    return this.msrp;
  }

  /**
   * Estimates the price if the manufacturing year is greater than
   * or equal to the Manufacturer Suggested Retail Price
   *
   * @return Float representing the updated base price (price)
   */
  public Float estimatePrice(){
    if (this.manufacturingYear >= 2023) {
      return this.msrp;
    }
    return ((float)(this.msrp - (msrp * (0.2 * (2023 - this.manufacturingYear)))));
  }
}









