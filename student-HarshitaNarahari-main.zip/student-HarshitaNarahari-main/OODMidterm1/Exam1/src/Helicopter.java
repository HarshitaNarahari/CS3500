/**
 * To represent a class for Helicopters
 */
public class Helicopter extends AAircraft{

  /**
   * Constructs an Helicopter
   */
  Helicopter(String id, int manufacturingYear, float msrp,
           MakeModel makeModel, int numQualifiedFlights){
    super(id, manufacturingYear, msrp, makeModel, numQualifiedFlights);
  }

  /**
   * Estimates the price if there are less than 1500 qualified flights
   *
   * @return Float representing the updated base price (price)
   */
  @Override
  public Float estimatePrice(){
    Float basePrice = super.estimatePrice();
    if (this.getnumQualifiedFlights() < 1500){
      basePrice /= (float) 1.3;
    }
    return basePrice;
  }
}