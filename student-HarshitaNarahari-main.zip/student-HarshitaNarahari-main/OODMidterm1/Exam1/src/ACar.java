/**
 * To represent an abstract class for Cars
 */
public abstract class ACar extends AVehicle{

  private BodyType bodyType;

  /**
   * Constructs a Car
   *
   * @throws IllegalArgumentException if Body type is null
   */
  ACar(String id, int manufacturingYear, float msrp, MakeModel makeModel, BodyType bodyType){
    super(id, manufacturingYear, msrp, makeModel);
    if (bodyType == null){
      throw new IllegalArgumentException("Body type cannot be null.");
    }
    this.bodyType = bodyType;
  }

  /**
   * This enum represents the body type of the car. A car
   * can either have a BodyType of a sedan, suv, hatchback,
   * van, truck, or convertible
   */
  enum BodyType {sedan, suv, hatchback, van, truck, convertible}

  /**
   * Estimates the price if the car's body type if convertible
   *
   * @return Float representing the updated base price (price)
   */
  public Float estimatePrice(){
    Float basePrice = super.estimatePrice();
    if (this.bodyType == BodyType.convertible){
      basePrice *= (float) 1.6;
    }
    return basePrice;
  }
}
