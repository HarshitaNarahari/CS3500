import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * To represent a class for testing the priceEstimate() method and exceptions
 */
public class PriceEstimationTest {

  // Examples for Testing
  private MakeModel mmUsedCar;
  private MakeModel mmNewCar;
  private MakeModel mmBoat;
  private MakeModel mmAirplane;
  private MakeModel mmHelicopter;
  private UsedCar usedCar;
  private UsedCar usedCarMileage;
  private UsedCar usedCarOwnerStat;
  private UsedCar usedCarAccidents;
  private UsedCar usedCarMilesStatus;
  private UsedCar usedCarMilesAccidents;

  private UsedCar usedCarAccidentsStatus;
  private NewCar newCar;
  private NewCar newCarAvailVehicles50m;
  private Boat boat;
  private Boat boatPassengers;
  private Boat boatSailPower;
  private Boat boatTrailableType;
  private Boat boatLengthPassengers;
  private Boat boatPassengersSailPower;
  private Boat boatPassengersTrailableType;
  private Boat boatPassengersLengthPassengers;
  private Airplane airplane;
  private Airplane airplaneQF;
  private Helicopter helicopter;
  private Helicopter helicopterQF100;
  private Helicopter helicopterQF1500;
  private Float basePriceUsedCar;
  private Float basePriceNewCar;
  private Float basePriceBoat;
  private Float basePriceAirplane;
  private Float basePriceHelicopter;


  void setUp() {
    mmUsedCar = new MakeModel("Honda", "Civic");
    mmNewCar = new MakeModel("Infiniti", "Classic");
    mmBoat = new MakeModel("Sailboat", "White");
    mmAirplane = new MakeModel("Delta", "Blue");
    mmHelicopter = new MakeModel("Hawaii", "Flowers");

    // USED CAR EXAMPLES
    // BASE PRICE = ((float)(10000 - (10000 * (0.2 * (2023 - 202q)))))
    basePriceUsedCar = (float) 6000;

    usedCar = new UsedCar("98005", 2021, (float) 10000,
            mmUsedCar, ACar.BodyType.suv, 5, 25000,
            4, 0, true);

    usedCarMileage = new UsedCar("98005", 2021, (float) 10000,
            mmUsedCar, ACar.BodyType.suv, 5, 300001,
            4, 0, true);

    usedCarOwnerStat = new UsedCar("98005", 2021, (float) 10000,
            mmUsedCar, ACar.BodyType.suv, 5, 25000,
            9, 0, false);

    usedCarAccidents = new UsedCar("98005", 2021, (float) 10000,
            mmUsedCar, ACar.BodyType.suv, 5, 25000,
            4, 4, true);

    usedCarMilesStatus = new UsedCar("98005", 2021, (float) 10000,
            mmUsedCar, ACar.BodyType.suv, 5, 300001,
            9, 0, false);

    usedCarMilesAccidents = new UsedCar("98005", 2021, (float) 10000,
            mmUsedCar, ACar.BodyType.suv, 5, 300001,
            4, 4, true);

    usedCarAccidentsStatus = new UsedCar("98005", 2021, (float) 10000,
            mmUsedCar, ACar.BodyType.suv, 5, 25000,
            9, 4, false);


    // NEW CAR EXAMPLES
    // BASE PRICE = ((float)(10000 - (10000 * (0.2 * (2023 - 2020)))))
    basePriceNewCar = (float) 4000;

    newCar = new NewCar("12345", 2020, (float) 10000, mmNewCar,
            ACar.BodyType.sedan, 20);

    newCarAvailVehicles50m = new NewCar("12345", 2020, (float) 10000, mmNewCar,
            ACar.BodyType.sedan, 2);


    // BOAT EXAMPLES
    // BASE PRICE = ((float)(10000 - (10000 * (0.2 * (2023 - 2022)))))
    basePriceBoat = (float) 8000;

    boat = new Boat("Sad000", 2022, (float) 10000, mmBoat,
            (float) 20.0, 5, true, Boat.PropulsionType.InboardEngine,
            Boat.BoatType.Bowriders);

    boatPassengers = new Boat("Sad000", 2022, (float) 10000, mmBoat,
            (float) 20.0, 8, true, Boat.PropulsionType.InboardEngine,
            Boat.BoatType.Bowriders);
    boatSailPower = new Boat("Sad000", 2022, (float) 10000, mmBoat,
            (float) 20.0, 5, true, Boat.PropulsionType.SailPower,
            Boat.BoatType.Bowriders);

    boatTrailableType = new Boat("Sad000", 2022, (float) 10000, mmBoat,
            (float) 20.0, 5, false, Boat.PropulsionType.InboardEngine,
            Boat.BoatType.FishingBoats);

    boatLengthPassengers = new Boat("Sad000", 2022, (float) 10000, mmBoat,
            (float) 20.0, 3, true, Boat.PropulsionType.InboardEngine,
            Boat.BoatType.Bowriders);

    boatPassengersSailPower = new Boat("Sad000", 2022, (float) 10000, mmBoat,
            (float) 20.0, 8, true, Boat.PropulsionType.SailPower,
            Boat.BoatType.Bowriders);

    boatPassengersTrailableType = new Boat("Sad000", 2022, (float) 10000, mmBoat,
            (float) 20.0, 8, false, Boat.PropulsionType.InboardEngine,
            Boat.BoatType.FishingBoats);

    boatPassengersLengthPassengers = new Boat("Sad000", 2022, (float) 10000, mmBoat,
            (float) 20.0, 8, true, Boat.PropulsionType.InboardEngine,
            Boat.BoatType.Bowriders);


    // AIRPLANE EXAMPLES
    // BASE PRICE = (float)(10000 * 1.1)
    basePriceAirplane = (float)(11000) * (float) 1.4;

    airplane = new Airplane("PrettyPink", 2019, (float) 10000,
            mmAirplane, 2000);

    airplaneQF = new Airplane("PrettyPink", 2019, (float) 10000,
            mmAirplane, 50);

    // HELICOPTER EXAMPLES
    // BASE PRICE = (float)(10000 * 1.1)
    basePriceHelicopter = (float)(11000);

    helicopter = new Helicopter("Hello", 2020, (float) 10000,
            mmHelicopter, 2000);
    helicopterQF100 = new Helicopter("Hello", 2020, (float) 10000,
            mmHelicopter, 50);
    helicopterQF1500 = new Helicopter("Hello", 2020, (float) 10000,
            mmHelicopter, 500);
  }


  @Test
  @Before
  public void testPlainBasePriceVehicles() {
    setUp();
    assertEquals(basePriceUsedCar, usedCar.estimatePrice(), 0.1);
    assertEquals(basePriceNewCar, newCar.estimatePrice(), 0.1);
    assertEquals(basePriceBoat, boat.estimatePrice(), 0.1);
  }

  @Test
  @Before
  public void testPlainBasePriceAircrafts() {
    setUp();
    assertEquals(basePriceAirplane, airplane.estimatePrice(), 0.1);
    assertEquals(basePriceHelicopter, helicopter.estimatePrice(), 0.1);
  }

  @Test
  @Before
  public void testPriceEstimate() {
    setUp();

    // Used Car Tests
    assertEquals(basePriceUsedCar * (float) 0.75, usedCarMileage.estimatePrice(), 0.1);
    assertEquals(basePriceUsedCar * (float) 0.8, usedCarOwnerStat.estimatePrice(), 0.1);
    assertEquals(basePriceUsedCar * (float) 0.65, usedCarAccidents.estimatePrice(), 0.1);
    assertEquals(basePriceUsedCar * (float) 0.75 * (float) 0.8, usedCarMilesStatus.estimatePrice(), 0.1);
    assertEquals(basePriceUsedCar * (float) 0.75 * (float) 0.65, usedCarMilesAccidents.estimatePrice(), 0.1);
    assertEquals(basePriceUsedCar * (float) 0.65 * (float) 0.8, usedCarAccidentsStatus.estimatePrice(), 0.1);

    // New Car Tests
    assertEquals(basePriceNewCar * (float) 1.2, newCarAvailVehicles50m.estimatePrice(), 0.1);

    // Boat tests
    assertEquals(basePriceBoat * (float) 1.3, boatPassengers.estimatePrice(), 0.1);
    assertEquals(basePriceBoat * (float) 1.25, boatSailPower.estimatePrice(), 0.1);
    assertEquals(basePriceBoat * (float) 0.9, boatTrailableType.estimatePrice(), 0.1);
    assertEquals(basePriceBoat * (float) 0.75, boatLengthPassengers.estimatePrice(), 0.1);

    assertEquals(basePriceBoat * (float) 1.3 * (float) 1.25, boatPassengersSailPower.estimatePrice(), 0.1);
    assertEquals(basePriceBoat * (float) 1.3 * (float) 0.9, boatPassengersTrailableType.estimatePrice(), 0.1);
    assertEquals(basePriceBoat * (float) 1.3, boatPassengersLengthPassengers.estimatePrice(), 0.1);

    // Airplane tests
    assertEquals(basePriceAirplane * (float) 1.3, airplaneQF.estimatePrice(), 0.1);

    // Helicopter tests
    assertEquals(((basePriceHelicopter/(float) 1.3) * (float) 1.3), helicopterQF100.estimatePrice(), 0.1);
    assertEquals((basePriceHelicopter/(float) 1.3), helicopterQF1500.estimatePrice(), 0.1);
  }

  @Test
  public void testExceptions() {
    // exception in AAircraft for Airplane
    try {
      Airplane airplane1 = new Airplane("PrettyPink", 2019, (float) 10000,
              mmAirplane, -5);
      fail("Number of qualified flights cannot be negative.");
    } catch (IllegalArgumentException e) {
    }

    // exception in AAircraft for Helicopter
    try {
      Helicopter helicopter1 = new Helicopter("Hello", 2010, (float) 7000,
              mmHelicopter, -50);
      fail("Number of qualified flights cannot be negative.");
    } catch (IllegalArgumentException e) {
    }

    // 1st exception in AVehicle for New Car
    try {
      NewCar newCar1 = new NewCar(null, 2020, (float) 5000, mmNewCar,
              ACar.BodyType.sedan, 2);
      fail("ID cannot be null.");
    } catch (IllegalArgumentException e) {
    }

    // 2nd exception in AVehicle for New Car
    try {
      NewCar newCar2 = new NewCar("12345", -2020, (float) 5000, mmNewCar,
              ACar.BodyType.sedan, 2);
      fail("Manufacturing year is negative.");
    } catch (IllegalArgumentException e) {
    }

    // 3rd exception in AVehicle for New Car
    try {
      NewCar newCar3 = new NewCar("12345", 2020, (float) -5000, mmNewCar,
              ACar.BodyType.sedan, 2);
      fail("The Manufacturer Suggested Retail Price is negative.");
    } catch (IllegalArgumentException e) {
    }

    // Exception in ACar for New Car - body type is null
    try {
      NewCar newCar4 = new NewCar("12345", 2020, (float) -5000, mmNewCar,
              null, 2);
      fail("Body type cannot be null.");
    } catch (IllegalArgumentException e) {
    }

    // Exception for New Car - Negative number of available vehicles within 50 miles
    try {
      NewCar newCar5 = new NewCar("12345", 2020, (float) 5000, mmNewCar,
              ACar.BodyType.sedan, -1);
      fail("There cannot be a negative number of available vehicles within 50 miles.");
    } catch (IllegalArgumentException e) {
    }

    // Exception for Used Car - Negative mileage
    try {
      ACar usedCar1 = new UsedCar("98005", 2004, (float) 40000,
              mmUsedCar, ACar.BodyType.convertible, 5, -250000,
              9, 0, true);
      fail("Mileage cannot be negative.");
    } catch (IllegalArgumentException e) {
    }

    // Exception for Used Car - Number of previous owners is negative
    try {
      ACar usedCar2 = new UsedCar("98005", 2004, (float) 40000,
              mmUsedCar, ACar.BodyType.convertible, 5, 250000,
              -9, 0, true);
      fail("Number of previous owners cannot be negative.");
    } catch (IllegalArgumentException e) {
    }

    // Exception for Used Car - Number of minor traffic accidents is negative
    try {
      ACar usedCar3 = new UsedCar("98005", 2004, (float) 40000,
              mmUsedCar, ACar.BodyType.convertible, 5, 250000,
              9, -5, true);
      fail("Number of minor traffic accidents cannot be negative.");
    } catch (IllegalArgumentException e) {
    }

    // Cases for exception in MakeModel for New Car - make is null, model is null, both are null
    try {
      MakeModel MMmakeNull = new MakeModel(null, "Civic");
      MakeModel MMmodelNull = new MakeModel("Honda", null);
      MakeModel MMbothNull = new MakeModel(null, null);
      fail("Make or model cannot be null.");
    } catch (IllegalArgumentException e) {
    }

    // Exception in Boat for Boat - boat length is negative
    try {
      Boat boat1 = new Boat("Sad000", 2000, (float) 10000, mmBoat,
              (float) -20.0, 10, true, Boat.PropulsionType.SailPower,
              Boat.BoatType.Bowriders);
      fail("The boat's length cannot be negative.");
    } catch (IllegalArgumentException e) {
    }

    // Exception in Boat for Boat - No passengers
    try {
      Boat boat2 = new Boat("Sad000", 2000, (float) 10000, mmBoat,
              (float) 20.0, 0, true, Boat.PropulsionType.SailPower,
              Boat.BoatType.Bowriders);
      fail("The boat must have at least one passenger.");
    } catch (IllegalArgumentException e) {
    }

    // Exception in Boat for Boat - boat type is null
    try {
      Boat boat3 = new Boat("Sad000", 2000, (float) 10000, mmBoat,
              (float) 20.0, 10, true, Boat.PropulsionType.SailPower,
              null);
      fail("The boat type cannot be null.");
    } catch (IllegalArgumentException e) {
    }

    // Exception in Boat for Boat - propulsion type is null
    try {
      Boat boat4 = new Boat("Sad000", 2000, (float) 10000, mmBoat,
              (float) 20.0, 10, true, null,
              Boat.BoatType.Bowriders);
      fail("The propulsion type cannot be null.");
    } catch (IllegalArgumentException e) {
    }
  }
}




