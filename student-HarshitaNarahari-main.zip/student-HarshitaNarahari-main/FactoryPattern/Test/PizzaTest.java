
public class PizzaTest {
  public static void main(String[] args) {
    PizzaStore p = new PizzaStore();
    p.orderPizza("Chicken");
  }
}
